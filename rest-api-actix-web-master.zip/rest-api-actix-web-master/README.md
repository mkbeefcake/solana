# rest-api-actix-web

# Setup

- Clone to your local env
- Install Postgresql https://www.postgresql.org/download
- Create Database 
- Setup Diesel https://diesel.rs/
- type `cargo watch` or `systemfd --no-pid -s http::5000 -- cargo watch -x run` in the project folder
